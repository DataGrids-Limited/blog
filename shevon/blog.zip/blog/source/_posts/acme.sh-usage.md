---
title: acme.sh使用说明
author: Dnomd343
language: zh-CN
date: 2020-7-3 14:32:55
index_img: /img/bg/thumb/scenery_real-003.jpg
banner_img: /img/bg/scenery_real-003.jpg
excerpt: acme.sh是一个基于Shell脚本编写的开源项目，用于向Let's Encrypt获取SSL/TLS证书，可以实现自动申请、续签、安装证书，让网站实现https访问。
---

# acme.sh使用说明

> [acme.sh](https://github.com/acmesh-official/acme.sh)是一个基于Shell脚本编写的开源项目，用于向Let's Encrypt获取SSL/TLS证书，可以实现自动申请、续签、安装证书，让网站实现https访问。

## 概述

[Let's Encrypt](https://letsencrypt.org/zh-cn/)是一个证书颁发机构(CA)，只要你有网站域名的控制权，你就可以用[ACME协议](https://tools.ietf.org/html/rfc8555)向它申请对应的(泛)证书；此外，Let's Encrypt推荐我们使用[ACME客户端](https://letsencrypt.org/zh-cn/docs/client-options/)（证书机器人）来实现自动申请、更新证书，而acme.sh就是针对ACME协议编写的工具，默认使用的CA就是Let's Encrypt，你可以直接在浏览器地址栏输入 `acme.sh` 跳转到它的GitHub项目地址，这里巧妙利用了 `.sh`（圣赫勒拿岛的区域代码）顶级域名。

> 对于含有非ASCII字符的域名（例如中文域名），需要先转为 `Punycode` ，由于Punycode的字符串中含有  `--`  ，使用时务必将整个域名用英文引号括起来，即 `"域名"` 格式。

> 对于一个域名，比如 `dnomd343.top` ，其泛域名证书颁发给 `*.dnomd343.top` ，此时主域名未被包含，因此申请时应同时指定 `dnomd343.top` 和 `*.dnomd343.top` 两个域名。

> 对于多级子域名，主域名的通配符证书并不适用，例如颁发给 `*.dnomd343.top` 的证书不适用于 `test.djnc.dnomd343.top` ，必须使用颁发给 `*.djnc.dnomd343.top` 的证书；此外，域名证书最多只支持一个通配符，即不存在 `*.*.dnomd343.top` 或类似的证书。

**acme.sh的命令格式：**

```bash
acme.sh 命令 ... [参数] ...
```

主要命令

+ `--help` 或 `-h` ：显示帮助信息

+ `--version` 或 `-v` ：显示版本信息

+ `--upgrade` ：检查更新

+ `--list` ：列出证书

+ `--issue` ：申请证书

+ `--renew` 或 `-r` ：更新证书

+ `--revoke` ：吊销证书

+ `--remove` ：删除证书

+ `--install-cert` ：安装证书

> acme.sh的高级功能较多，它们的具体使用可用查阅[官方Wiki](https://github.com/acmesh-official/acme.sh/wiki)和[参数说明](https://github.com/acmesh-official/acme.sh/wiki/Options-and-Params)
>
>但是它的使用非常简单，主要分为 `安装脚本`、`申请证书`、`安装证书` 三部分。

## 安装acme.sh

使用如下命令自动安装

```bash
shell> curl https://get.acme.sh | sh
···
```

安装完成后，重启窗口让 `acme.sh` 指向 `~/.acme.sh/acme.sh` ，此后就可直接使用 `acme.sh` 命令。

> acme.sh的安装不需要root权限，安装过程不会污染已有的系统任何功能和文件，所有的修改都被限制在 `~/.acme.sh/` 中

如果你想在安装的时候指定各种参数，也可以克隆GitHub仓库手动安装，更多详细参数可参考[官方说明](https://github.com/acmesh-official/acme.sh/wiki/How-to-install#4-advanced-installation)

```bash
shell> git clone https://github.com/acmesh-official/acme.sh.git
# 如果国内速度连接失败或者速度太慢，可换用如下命令
# shell> git clone https://hub.fastgit.org/acmesh-official/acme.sh.git
shell> cd ./acme.sh
shell> ./acme.sh --install \
  --home ··· \
  --config-home ··· \
  --cert-home  ··· \
  --accountemail  ··· \
  ···
```

## 申请证书

> acme.sh主要有三种申请方式：
> + DNS API模式：推荐，简单稳定好用
>
> + DNS手动模式：不推荐，仅测试使用
>
> + Web服务器模式：一般推荐，偶尔会有些小问题
>
> 更多详细信息可参考[官方文档](https://github.com/acmesh-official/acme.sh/wiki/How-to-issue-a-cert)

需要的命令：

+ `--issue` ：执行证书申请

+ `--renew` 或 `-r` ：更新证书

对应的参数：

+ `--dns` ：指定为DNS模式

+ `--domain` 或 `-d` ：指定域名

+ `--webroot` 或 `-w` ：指定域名指向服务的根目录

### DNS API模式

> 这个模式只需要你输入域名服务商提供的 `Key`（有的还需要 `Secret`），其余工作由acme.sh自动完成（包括申请、续签、安装等）

各家对域名的 `API Key` 的称呼不大相同，acme.sh的[文档](https://github.com/acmesh-official/acme.sh/wiki/dnsapi)中给出了各服务商的申请方式。

一般情况下，你会从域名服务商拿到访问许可，然后执行如下命令：

```bash
# 将许可信息写入临时环境变量，可用env命令查看
shell> export ···=···
shell> export ···=···
# 执行申请
shell> acme.sh --issue --dns dns_··· -d 域名1 -d 域名2 ···
```

这里以阿里云为例，申请 `dnomd343.top` 的全部证书。

首先在[这里](https://usercenter.console.aliyun.com/#/manage/ak)拿到用户的 `AccessKey ID` 和 `AccessKey Secret`，然后执行如下命令：

```bash
# 阿里云域名访问的AccessKey
shell> export Ali_Key="···"
shell> export Ali_Secret="···"
# 申请主域名证书和泛域名证书
shell> acme.sh --issue --dns dns_ali -d dnomd343.top -d *.dnomd343.top
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top/fullchain.cer
```

> 注意：域名服务商给你的访问许可非常重要，千万不要泄露，否则其他人将会拿到你的域名控制权；建议执行完上述命令请重启窗口销毁临时环境变量。

### DNS手动模式

> 这个模式需要你填入要申请的域名，acme.sh会返回一个子域名和一串TXT数据，你需要手动把它们添加到你的域名解析中，然后回来申请证书。

如果你是第一次申请该域名，需要你加上 `--yes-I-know-dns-manual-mode-enough-go-ahead-please` 参数，其他要求可用参考[官方文档](https://github.com/acmesh-official/acme.sh/wiki/dns-manual-mode)。

执行如下命令：

```bash
# 发起申请
shell> acme.sh --issue --dns -d 域名1 -d 域名2 ···
# 第一次申请在后面加上"--yes-I-know-dns-manual-mode-enough-go-ahead-please"
···
Add the following TXT record:
Domain: '_acme-challenge.···'
TXT value: '···'
···
# 手动把它们添加到你的域名解析中再执行下列步骤
# 申请证书
shell> acme.sh --issue --renew -d 域名1 -d 域名2 ···
# 第一次也要加上"--yes-I-know-dns-manual-mode-enough-go-ahead-please"
···
Cert success.
···
```

此处以 `dnomd343.top` 为例，申请该域名的全部证书。

```bash
# 发起申请
shell> acme.sh --issue --dns -d dnomd343.top -d *.dnomd343.top
···
Add the following TXT record:
Domain: '_acme-challenge.dnomd343.top'
TXT value: '···'
···
# 将TXT记录添加到域名解析中
# 申请证书
shell> acme.sh --issue --renew -d dnomd343.top -d *.dnomd343.top
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top/fullchain.cer
```

> 注意：这个模式需要你手动添加TXT记录做验证，由于Let's Encrypt的证书需要每三个月续签一次，忘记续签就会导致证书过期从而使https连接出错，因此不建议本方式长期使用。

### Web服务器模式

> 这个模式需要你将域名指向你的Web服务器，并将网站根目录地址提交给acme.sh，之后若需要正常续签需要保持该目录不变。
>
> 注意：本方式对泛域名支持不完整。

执行命令如下：

```bash
shell> acme.sh --issue -d 域名 --webroot 网站根目录地址
···
Cert success.
···
```

此处以 `test.dnomd343.top` 为例，申请该域名的证书；申请前先将 `test.dnomd343.top` 指向本机，并用nginx代理到 `/var/www/test/` 下面。

```bash
shell> acme.sh --issue -d test.dnomd343.top --webroot /var/www/test/
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/test.dnomd343.top/test.dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/test.dnomd343.top/test.dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/test.dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/test.dnomd343.top/fullchain.cer
```

> 如果你本机没有web代理工具，可以使用 `--standalone` 参数自动获取，同时可用 `--httpport` 指定http端口；如果你是TLS服务器，可用使用 `--alpn` 参数自动获取，同时可用 `--tlsport` 指定https端口。
>
> 如果你本机有Nginx或者Apache服务，使用 `--nginx` 或 `--apache` 参数可用自动识别其配置文件并找到网站根目录。
>
> 更多用法请参考[官方文档](https://github.com/acmesh-official/acme.sh/wiki/How-to-issue-a-cert)


## 安装证书

> 注意：不要直接用 `.acme.sh/`内的证书文件，里面目录结构随使可能会因为脚本自动更新而变动。

官方有提供了关于Nginx/Apache的[安装方法](https://github.com/acmesh-official/acme.sh#3-install-the-cert-to-apachenginx-etc)

需要的命令：

+ `--install-cert` ：安装证书

+ `--list` ：列出所有申请的证书

对应的参数：

+ `--key-file` ：私钥文件安装地址

+ `--cert-file` ：证书文件安装地址

+ `--fullchain-file` ：证书链文件安装地址

+ `--reloadcmd` ：重启命令内容

下面以nginx证书安装为例：

先配置nginx

> 存放配置的文件夹一般为 `/etc/nginx/conf.d/`，在其下新建 `dnomd343.conf` 文件；

```bash
server {
    listen 80; # 监听80端口(http)
    server_name dnomd343.top;
    return 301 https://$server_name$request_uri; # 返回301命令，将地址重写到https上
}

server {
    listen 443 ssl; # 监听443端口(https)
    server_name dnomd343.top;
    root /var/www/dnomd343; # 指定网站根目录
    ssl_certificate /etc/ssl/certs/dnomd343.top/fullchain.pem; # 指定SSL/TLS证书
    ssl_certificate_key /etc/ssl/certs/dnomd343.top/privkey.pem;

    location / {
        index index.html; # 默认加载文件
    }
}
```

> 注意，请确认你的服务器防火墙是否拦截 `80` 和 `443` 端口，包括云服务商提供的防火墙和系统上安装的防火墙。

将 `dnomd343.top` 的 `A记录` 指向本机IP地址，此配置将让其代理到 `/var/www/dnomd343/` 文件夹下，同时使用 `/etc/ssl/certs/dnomd343.top/` 内的证书文件；

> 注意：若nginx版本低于v1.15.x，务必将 `listen 443 ssl` 改为 `listen 443`，并在下方加入命令 `ssl on`；

查看证书申请状态：

```bash
# 列出全部证书
shell> acme.sh --list
Main_Domain   KeyLength  SAN_Domains     CA               Created   Renew
dnomd343.top  ""         *.dnomd343.top  LetsEncrypt.org  ···       ···
```

安装证书到nginx，安装完成后会重启nginx使命令生效。

> 注意此处要用 `force-reload` 命令，否则nginx不会自动更新证书文件。

```bash
# 创建文件夹
shell> mkdir -p /etc/ssl/certs/dnomd343.top/
# 安装证书
shell> acme.sh --install-cert -d dnomd343.top  \
--key-file       /etc/ssl/certs/dnomd343.top/privkey.pem \
--fullchain-file /etc/ssl/certs/dnomd343.top/fullchain.pem  \
--reloadcmd      "systemctl force-reload nginx"
···
Installing key to:/etc/ssl/certs/dnomd343.top/privkey.pem
Installing full chain to:/etc/ssl/certs/dnomd343.top/fullchain.pem
Run reload cmd: systemctl force-reload nginx
Reload success
```

为了确保服务启动成功，可以查看nginx监听端口的状态

```bash
# 查看80端口(http)状态
shell> netstat -tlnp | grep 80
tcp     0     0 0.0.0.0:80       0.0.0.0:*     LISTEN      7227/nginx: master
tcp6    0     0 :::80            :::*          LISTEN      7227/nginx: master
# 查看443端口(https)状态
shell> netstat -tlnp | grep 443
tcp     0     0 0.0.0.0:443      0.0.0.0:*     LISTEN      7227/nginx: master
```

证书安装信息会记录在 `~/.acme.sh/dnomd343.top/dnomd343.top.conf` 中，可以发现该文件末尾添加了如下信息：

> `Le_ReloadCmd` 中将命令记录为 `base64` 格式

```bash
# 查看安装信息
shell> cat ~/.acme.sh/dnomd343.top/dnomd343.top.conf
···
Le_RealCertPath=''
Le_RealCACertPath=''
Le_RealKeyPath='/etc/ssl/certs/dnomd343.top/privkey.pem'
Le_ReloadCmd='__ACME_BASE64__START_c3lzdGVtY3RsIGZvcmNlLXJlbG9hZCBuZ2lueA==__ACME_BASE64__END_'
Le_RealFullChainPath='/etc/ssl/certs/dnomd343.top/fullchain.pem'
# 查看安装目录情况
shell> ls /etc/ssl/certs/dnomd343.top/
fullchain.pem  privkey.pem
```

如果你想修改安装配置，可修改上述文件，或直接运行新的安装命令，即可覆盖上一次的配置；如果想删除安装配置，可直接运行无参数的安装命令：

```bash
# 删除之前的安装信息
shell> acme.sh --install-cert -d dnomd343.top
# 但是不会删除已安装的证书，需要你手动删除
```

## 更新证书

> 你可以手动更新证书，但是如果时间还没到你需要加上 `--force` 参数

命令：

+ `--renew` 或 `-r` ：更新证书

对应参数：

+ `--domain` 或 `-d` ：指定域名

+ `--force` ：强制更新

```bash
# 更新证书
shell> acme.sh --renew -d dnomd343.top --force
Renew: 'dnomd343.top'
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top/fullchain.cer
```

## 吊销证书

> 如果你的私钥文件泄露或者不再使用，可以选择吊销该证书
>
> 注意：关于OCSP服务器被墙问题，请查看下方[OCSP](#OCSP问题)的内容

命令：

+ `--revoke` ：吊销证书

对应参数：

+ `--domain` 或 `-d` ：指定域名

```bash
# 吊销证书
shell> acme.sh --revoke -d dnomd343.top
Try domain key first.
Revoke success.
```

更多详细信息可参考[官方文档](https://github.com/acmesh-official/acme.sh/wiki/revokecert)

## 删除证书

> 用于从acme.sh中移除该证书，但并不吊销该证书

命令：

+ `--remove` ：移除证书

对应参数：

+ `--domain` 或 `-d` ：指定域名

```bash
# 移除证书
shell> acme.sh --remove -d dnomd343.top
dnomd343.top is removed, the key and cert files are in /home/dnomd343/.acme.sh/dnomd343.top
You can remove them by yourself.
```

> 执行证书移除命令后，acme.sh仅不再参与该证书的工作，但证书文件仍然在 `~/acme.sh` 文件夹下，需要用户手动删除。

## ECC证书

目前最常用的密钥交换算法有 `RSA` 和 `ECDHE`：

+ RSA历史悠久，兼容性好，但计算相对较慢；

+ ECDHE使用了ECC算法，计算速度快，但兼容性相对较差；

内置ECDSA公钥的证书一般被称之为ECC证书，内置RSA公钥的证书称为RSA证书；ECC算法在计算复杂度远小于RSA，但是却能在更小的长度上得到RSA的同款安全等级，一般认为 256 位 `ECC Key` 在安全性上等同于 3072 位 `RSA Key`，所以ECC证书不仅体积小，运算速度也更快。

诚然，ECC证书有压倒性的优势，但是由于历史原因，它在旧系统的兼容性上存在不少问题，比如XP及之前的Windows系统都原生不支持（火狐浏览器除外），但是如果你不打算兼容老系统，使用ECC无疑更有优势。

你可以在[这里](https://imququ.com/post/ecc-certificate.html)获取更多关于ECC证书的知识。

acme.sh也申请ECC证书，仅需加上一些参数，操作上并无太大变化；目前acme.sh支持以下三类可选长度：
+ ec-256（推荐使用）
+ ec-384
+ ec-521（不完善）

同样使用上面的示例，我们尝试为 `dnomd343.top` 申请主域名和泛域名证书：

申请证书使用DNS API模式：

```bash
# 添加AccessKey
shell> export Ali_Key="···"
shell> export Ali_Secret="···"
# 使用DNS API申请ECC证书，这里使用ec-256，仅需添加--keylength参数
shell> acme.sh --issue --dns dns_ali -d dnomd343.top -d *.dnomd343.top --keylength ec-256
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top_ecc/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top_ecc/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top_ecc/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top_ecc/fullchain.cer
# 生成在 `~/.acme.sh/` 下的证书文件夹会加上 `_ecc` 后缀
```

证书安装：

```bash
# 创建证书文件夹
shell> mkdir -p /etc/ssl/certs/dnomd343.top/
# 安装时加上--ecc参数
shell> acme.sh --install-cert -d dnomd343.top --ecc \
--key-file       /etc/ssl/certs/dnomd343.top/privkey.pem \
--fullchain-file /etc/ssl/certs/dnomd343.top/fullchain.pem \
--reloadcmd      "systemctl force-reload nginx"
···
Installing key to:/etc/ssl/certs/dnomd343.top/privkey.pem
Installing full chain to:/etc/ssl/certs/dnomd343.top/fullchain.pem
Run reload cmd: systemctl force-reload nginx
Reload success
```

其他几个命令也都是加上 `--ecc` 参数：

```bash
# 更新证书，加上--ecc参数
shell> acme.sh --renew -d dnomd343.top --force --ecc
Renew: 'dnomd343.top'
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top/fullchain.cer
```

```bash
# 吊销证书，加上--ecc参数
shell> acme.sh --revoke -d dnomd343.top --ecc
Try domain key first.
Revoke success.
```

```bash
# 移除证书，加上--ecc参数
shell> acme.sh --remove -d dnomd343.top --ecc
dnomd343.top is removed, the key and cert files are in /home/dnomd343/.acme.sh/dnomd343.top
You can remove them by yourself.
```

## OCSP问题

> [OCSP](https://zh.wikipedia.org/zh-cn/%E5%9C%A8%E7%BA%BF%E8%AF%81%E4%B9%A6%E7%8A%B6%E6%80%81%E5%8D%8F%E8%AE%AE)(Online Certificate Status Protocol)在线证书状态协议，是一种确保证书安全的机制。

简而言之，OCSP的作用就是用于判断当前证书状态，主要是向服务器查询证书是否被吊销；浏览器一般会在首次建立https连接时会去向OCSP服务器验证证书的有效性，不同浏览器对OSCP服务器失效的规则不同，例如Chrome浏览器不进行OCSP检查，火狐浏览器检查会有2s-4s的超时时间，而IE可能会达到数十秒；幸运的是，大部分情况下，浏览器短时间内访问同一域名时，只在第一次进行OCSP检查，此外，即使OCSP服务器断连，浏览器在等待足够长的时间后仍会正常加载网页，但后果就是影响网页打开速度。

不幸的是，Let's Encrypt的OCSP服务器被“墙”了，这将导致使用它签发证书的网站在一部分浏览器第一次打开时发生卡顿，虽然不会导致网站完全断连，但是会严重影响浏览体验（Chrome浏览器除外）；此外，处于国内的服务器在申请Let's Encrypt证书或者续签时，一部分证书机器人可能会卡死或者失败。

在2020年4月1号早上10点左右，Let's Encrypt的OCSP服务器在中国大陆开始被DNS污染，大约两三天后，其境内解析在IPv4上基本不可用，IPv6部分地区异常；Let's Encrypt的OCSP服务器域名为 `ocsp.int-x3.letsencrypt.org` ，其CNAME指向 `a771.dscq.akamai.net` （Akamai公司的a771节点），它被DNS污染以后导致OCSP域名无法解析到正确的服务器上，间接导致国内的OCSP请求异常。由于证书的申请和续签是由 `acme-v02.api.letsencrypt.org` 处理的，中间并不需要OCSP服务器参与，目前该域名工作仍然正常，所以原则上OCSP即使失效也不会影响到证书签名请求（CSR），具体过程可以参考Let's Encrypt的[描述文档](https://letsencrypt.org/zh-cn/how-it-works/)。

你可以在[这里](http://ping.chinaz.com/ocsp.int-x3.letsencrypt.org)直观地看到它的DNS污染被情况，截至七月，国内有少部分地区恢复正常，但绝大多数区域仍然无法正常访问；而Let's Encrypt的员工则表示会向Akamai合作寻求[解决方案](https://community.letsencrypt.org/t/ocsp-int-x3-letsencrypt-org-is-not-working-in-china)，而目前似乎并没有很好的效果。

至今仍无法得知Let's Encrypt的OCSP服务器为何会被墙，它并没有违反任何相关法律，反而为国内网络安全做出了不少的贡献；但由于目前被屏蔽的实际上是Akamai公司的a771节点，因此主流观点认为是有违规网站同时也在使用该节点，从而间接导致了整个节点上的服务都受到冲击，但奇怪的是GFW仅进行了DNS污染，并未出现明显的劫持行为；也有阴谋论观点认为，Let's Encrypt触及到国内某些传统证书签发商的利益，从而遭受国家公权力的干涉，但是目前它的acme申请接口仍然正常，难以佐证这个观点；总之，无人知晓确切原因是什么。

由于acme.sh的默认CA就是Let's Encrypt，其申请得到的证书在国内访问时可能会受到一定的影响，但最直接最严重的后果就是吊销证书对国内互联网完全无效，而且是无解的：这在证书私钥泄露时将会导致严重安全问题，由于浏览器OCSP请求失败，无法得知当前证书是否安全，因而拿到私钥的人可以直接发起针对https网络的 `中间人` 攻击。

GFW对这种互联网基础服务下手确实让人猝不及防，由于这种情况史无前例，目前也仅有一些补救方法来缓解非Chrome用户访问卡顿的问题，主流方法就是使用 `OCSP Stapling` （服务端主动将认证的OCSP查询结果随证书一起发送），让客户端无需再连接OCSP服务器做验证，从而缓解卡顿问题，但并非所有浏览器都支持，这在兼容性上将会大打折扣；我们目前能做的也就是等待Let's Encrypt主动更换节点或者GFW对其解封。

## 写在最后

Let's Encrypt是由Mozilla、Cisco、Akamai等发起的非营利性组织，提供了完全免费的泛域名证书，而且在兼容性上做得比一些付费证书还好，着实在推动了https普及；相比于此前动辄数千块钱一年的证书，它对个人建站极其友好，但也对提供付费证书的传统商家有不小的打击。

SSL证书的意义不仅仅在于加密通讯，更有身份认证的作用，在很大程度上避免了中间人攻击的发生，所以部署https在大多数情况下是有利无弊的；但由于Let's Encrypt的OCSP服务器在国内被墙导致无法吊销证书，一旦私钥泄露网站将会有危险，因此对于有较高安全要求或者涉及支付的网站，不建议使用这款证书。

实际上，大多数的个人网站并没有被攻击的意义，如果你真的介意这一点，阿里云或者腾讯云也提供免费的DV SLL证书，但只支持单域名且有个数限制，且不能通过脚本自动续签，不过稳定性和兼容性也很棒，也可以正常被吊销，有效期一般是一年。

无疑，acme.sh是申请Let's Encrypt证书的优秀工具，在操作和功能上要强于其他证书机器人，由于全靠Shell脚本驱动，其稳定性也很高；上文对acme.sh的讲解也基本涵盖了单域名的操作，如果你还想了解它的更多命令和原理，可以去查阅它的Github项目WiKi或源码。
