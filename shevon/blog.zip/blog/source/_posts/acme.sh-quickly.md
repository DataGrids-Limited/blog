---
title: acme.sh快速上手
author: Dnomd343
language: zh-CN
date: 2020-7-2 02:43:41
index_img: /img/bg/thumb/scenery_real-005.jpg
banner_img: /img/bg/scenery_real-005.jpg
excerpt: 使用acme.sh脚本快速获取SSL证书，以及实现https访问。
---

# acme.sh快速上手

> [acme.sh](https://github.com/acmesh-official/acme.sh)是一个获取SSL证书的开源项目，可以实现自动申请、续签、安装证书，让网站实现https访问。

> 本文档侧重于快速上手使用，更多高级用法请查阅[acme.sh使用说明](https://blog.dnomd343.top/acme.sh-usage)或[acme.sh官方Wiki](https://github.com/acmesh-official/acme.sh/wiki)。

## 概述

acme.sh是针对ACME协议编写的工具，默认使用的CA是[Let's Encrypt](https://letsencrypt.org/zh-cn/)；只要你有域名的控制权，就可以在一分钟内拿到一张有效期三个月的泛域名证书，而acme.sh也可以实现自动申请、续签、安装证书。

> 对于含有非ASCII字符的域名（例如中文域名），需要先转为 `Punycode` ，由于Punycode的字符串中含有  `--`  ，使用时务必将整个域名用英文引号括起来，即 `"域名"` 格式。

> 对于一个域名，比如 `dnomd343.top` ，其泛域名证书颁发给 `*.dnomd343.top` ，此时主域名未被包含，因此申请时应同时指定 `dnomd343.top` 和 `*.dnomd343.top` 两个域名。

> 对于多级子域名，主域名的通配符证书并不适用，例如颁发给 `*.dnomd343.top` 的证书不适用于 `test.djnc.dnomd343.top` ，必须使用颁发给 `*.djnc.dnomd343.top` 的证书；此外，域名证书最多只支持一个通配符，即不存在 `*.*.dnomd343.top` 或类似的证书。



## 安装acme.sh

> acme.sh的安装不需要root权限，安装过程不会污染已有的系统任何功能和文件，所有的修改都被限制在 `~/.acme.sh/` 中

使用如下命令自动安装

```bash
shell> curl https://get.acme.sh | sh
···
```

安装完成后，重新连接窗口

```bash
#
shell> acme.sh --version
https://github.com/acmesh-official/acme.sh
v2.8.8
```

成功输出版本号即安装成功

## 申请证书

> acme.sh有多种证书申请方式，这里只介绍 `DNS API模式` ，这个模式只需要提供域名服务商分配给你账号的凭证，acme.sh会自动用它自动申请、续签证书，整个过程无需用户干预，只要你的服务器能访问网络就可以拿到证书。

大部分域名服务商都会给用户提供API接口方便程序操作，其凭证一般称为 `API Key` ，acme.sh的[文档](https://github.com/acmesh-official/acme.sh/wiki/dnsapi)中列出百余家服务商的使用方法。

这里以阿里云为例，申请 `dnomd343.top` 的全部证书；首先在[阿里云AccessKey控制台](https://usercenter.console.aliyun.com/#/manage/ak)拿到用户的 `AccessKey ID` 和 `AccessKey Secret`，然后执行如下命令：

```bash
# 阿里云域名访问的AccessKey
shell> export Ali_Key="···"
shell> export Ali_Secret="···"
# 申请主域名证书和泛域名证书
shell> acme.sh --issue --dns dns_ali -d dnomd343.top -d *.dnomd343.top
···
Cert success.
···
Your cert is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.cer
Your cert key is in  /home/dnomd343/.acme.sh/dnomd343.top/dnomd343.top.key
The intermediate CA cert is in  /home/dnomd343/.acme.sh/dnomd343.top/ca.cer
And the full chain certs is there:  /home/dnomd343/.acme.sh/dnomd343.top/fullchain.cer
```

此时证书申请成功，文件放置在 `/home/dnomd343/.acme.sh/dnomd343.top` 下面。


## 安装证书

> 注意：不要直接用 `.acme.sh/`内的证书文件，里面目录结构随使可能会因为脚本自动更新而变动。

下面以nginx证书安装为例：

### 配置nginx

> 存放配置的文件夹一般为 `/etc/nginx/conf.d/`，在其下新建 `dnomd343.conf` 文件；下面配置文件将 `dnomd343.top` 映射到 `/var/www/dnomd343/` 目录下，使用 `/etc/ssl/certs/dnomd343.top` 下的证书文件配置https，并强制将http重写到https。

```bash
server {
    listen 80; # 监听80端口(http)
    server_name dnomd343.top;
    return 301 https://$server_name$request_uri; # 返回301命令，将地址重写到https上
}

server {
    listen 443 ssl; # 监听443端口(https)
    server_name dnomd343.top;
    root /var/www/dnomd343; # 指定网站根目录
    ssl_certificate /etc/ssl/certs/dnomd343.top/fullchain.pem; # 指定SSL/TLS证书
    ssl_certificate_key /etc/ssl/certs/dnomd343.top/privkey.pem;

    location / {
        index index.html; # 默认加载文件
    }
}
```

在 `dnomd343.top` 域名解析中，配置 `@` 的 `A` 记录指向本机的IP地址。

> 注意，请确认你的服务器防火墙是否拦截 `80` 和 `443` 端口，包括云服务商提供的防火墙和系统上安装的防火墙。

### 给nginx安装

> 将证书安装到 `/etc/ssl/certs/dnomd343.top` 下，并配置nginx的重启命令

查看证书申请状态：

```bash
# 列出全部证书
shell> acme.sh --list
Main_Domain   KeyLength  SAN_Domains     CA               Created   Renew
dnomd343.top  ""         *.dnomd343.top  LetsEncrypt.org  ···       ···
```

安装证书到nginx，安装完成后会重启nginx使命令生效。

```bash
# 创建文件夹
shell> mkdir -p /etc/ssl/certs/dnomd343.top/
# 安装证书
shell> acme.sh --install-cert -d dnomd343.top  \
--key-file       /etc/ssl/certs/dnomd343.top/privkey.pem \
--fullchain-file /etc/ssl/certs/dnomd343.top/fullchain.pem  \
--reloadcmd      "systemctl force-reload nginx"
···
Installing key to:/etc/ssl/certs/dnomd343.top/privkey.pem
Installing full chain to:/etc/ssl/certs/dnomd343.top/fullchain.pem
Run reload cmd: systemctl force-reload nginx
Reload success
```

为了确保服务启动成功，可以查看nginx监听端口的状态

```bash
# 查看80端口(http)状态
shell> netstat -tlnp | grep 80
tcp     0     0 0.0.0.0:80       0.0.0.0:*     LISTEN      7227/nginx: master
tcp6    0     0 :::80            :::*          LISTEN      7227/nginx: master
# 查看443端口(https)状态
shell> netstat -tlnp | grep 443
tcp     0     0 0.0.0.0:443      0.0.0.0:*     LISTEN      7227/nginx: master
```

若上述命令均未报错，则证书安装成功，访问 `https://dnomd343.com/` 确认是否配置成功。
