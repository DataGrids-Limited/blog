---
title: MySQL的部署与适配
author: Dnomd343
language: zh-CN
date: 2020-5-19 08:45:03
index_img: /img/bg/thumb/scenery_real-002.jpg
banner_img: /img/bg/scenery_real-002.jpg
excerpt: 在CentOS上安装MySQL8.x，配置多用户及其权限。
---

# CentOS安装MySQL8.x

> MySQL是一个开源的关系型数据库系统，下文介绍如何在CentOS上安部署MySQL服务。

## 概述

> 数据库一般分为 `关系型数据库`（MySQL、SQL Server、Oracle等）和 `非关系型数据库`（Membase、MongoDB等）；关系型数据库管理系统简称RDBMS(Relational Database Management System)，MySQL就是典型的关系型数据库之一，使用GPL许可分发，开源免费，但之后它被Oracle收购，推出了商业版；由于GPL许可是不可撤销的，因此目前的MySQL分为 `商业版` 和 `社区版` ，其中社区版仍然保持开源免费。

[MySQL官网](https://www.mysql.com/)

[MySQL文档](https://dev.mysql.com/doc/)

[MySQL下载](https://dev.mysql.com/downloads/)

> MySQL常见版本有5.x与8.x，这里安装新的8.0版本

MySQL有Server和Client两类

+ MySQL-Server用于服务端，安装在服务器上

+ MySQL-Client用于发起客户端请求，安装在个人设备上

此处安装MySQL-Server，它会同时安装MySQL-Client组件

> 由于Oracle此前的一些不光彩作为，开源社区并不对其抱有多大信任，MySQL的创始人Michael Widenius重新主导开发了 `MariaDB` （名字取自他的女儿Maria）作为MySQL的一条分支，采用GPL授权，并与MySQL保持兼容；MariaDB的目的就是完全兼容MySQL，使之在必要的时候能轻松成为MySQL的代替品。

以下安装过程建议在root用户下执行

## 检查安装

> 一般情况下，安装MySQL的时候会覆盖掉之前已存在的mariadb，但保险起还是建议执行以下步骤

```bash
# 查看之前是否安装mariadb，如果不输出直接跳到下一步
shell> yum list installed | grep mariadb
mariadb-libs.x86_64              1:5.5.65-1.el7
···
```

```bash
# 卸载上面有列出的包
shell> yum remove -y mariadb-libs
shell> yum remove -y ···
shell> ···
```

```bash
# 查看之前是否安装mysql，如果不输出直接跳到下一步
shell> yum list installed | grep mysql
···
```

```bash
# 同样卸载列出的包
shell> yum remove -y ···
shell> ···
```

## 配置MySQL源

> CentOS7之后，yum安装MySQL会默认安装MariaDB，所以这里需要改用MySQL官方提供的yum源。

你可以在[MySQL Yum Repository](https://dev.mysql.com/downloads/repo/yum/)找到不同系统版本的RPM包

CentOS7系统目前适配 `mysql80-community-release-el7-3.noarch.rpm`

> 下方以 `el7-3` 版本为例，如果你是其他版本请替换该部分内容

```bash
# 下载RPM包
shell> wget https://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm
···

#安装RPM包
shell> rpm -Uvh mysql80-community-release-el7-3.noarch.rpm
···

# 删除RPM包
shell> rm -f mysql80-community-release-el7-3.noarch.rpm
```

```bash
# 验证安装
shell> yum repolist enabled | grep "mysql.*community.*"
mysql-connectors-community/x86_64 MySQL Connectors Community
mysql-tools-community/x86_64      MySQL Tools Community
mysql80-community/x86_64          MySQL 8.0 Community Server
···
# 若输出以上信息，则RPM包安装成功
```

## 安装MySQL
> 安装 `mysql-community-server` 及其依赖和组件，包括 `mysql-community-client` 、`mysql-community-common` 、`mysql-community-libs`等。

```bash
# 更新应用
shell> yum update -y
···

# 安装MySQL
shell> yum install -y mysql-community-server
···
# 本命令执行时间较久，请耐心等待
```

## 启动MySQL

> 开启 `mysqld` 服务

```bash
# 启动服务
shell> systemctl start mysqld

# 设置为开机启动
shell> systemctl enable mysqld

# 查看服务运行情况
shell> systemctl status mysqld
···
# 出现下列语句即服务运行正常
# Active: active (running) since ···
```

## 配置root
> MySQL安装后会自动创建管理员账号 `root@localhost` ，其初始密码存储在日志文件 `/var/log/mysqld.log` 中

```bash
# 查询日志得到初始密码
shell> grep 'password' /var/log/mysqld.log
··· A temporary password is generated for root@localhost: ···

# 以root身份登录MySQL
shell> mysql -uroot -p
Enter password:
···

# 设置root密码
mysql> ALTER USER root@localhost IDENTIFIED BY '你的密码';
···
# 如果出现以下错误请将密码设置得更复杂（包含大小写，数字与特殊字符）
# ERROR 1819 (HY000): Your password does not satisfy the current policy requirements
# 或者执行 SET GLOBAL validate_password.policy=0; 来降低密码强度要求
```

## 配置密码策略

> MySQL的默认密码策略要求较高，如果平时仅需要简单密码，可在此处修改密码强度要求

```bash
# 以root身份登录
shell> mysql -uroot -p
···

mysql> SHOW VARIABLES LIKE "validate_password%";
+--------------------------------------+--------+
| Variable_name                        | Value  |
+--------------------------------------+--------+
| validate_password.check_user_name    | ON     |
| validate_password.dictionary_file    |        |
| validate_password.length             | 8      |
| validate_password.mixed_case_count   | 1      |
| validate_password.number_count       | 1      |
| validate_password.policy             | MEDIUM |
| validate_password.special_char_count | 1      |
+--------------------------------------+--------+
7 rows in set (0.00 sec)

# 将密码要求从MEDIUM改为LOW
mysql> SET GLOBAL validate_password.policy=0;

# 再查看密码策略，此时已经将要求改为LOW
mysql> SHOW VARIABLES LIKE "validate_password%";
+--------------------------------------+-------+
| Variable_name                        | Value |
+--------------------------------------+-------+
| validate_password.check_user_name    | ON    |
| validate_password.dictionary_file    |       |
| validate_password.length             | 8     |
| validate_password.mixed_case_count   | 1     |
| validate_password.number_count       | 1     |
| validate_password.policy             | LOW   |
| validate_password.special_char_count | 1     |
+--------------------------------------+-------+
7 rows in set (0.00 sec)
```

## 用户及其权限管理

MySQL的用户名格式为 `'username'@'host'` ，username指定用户名，host指定该用户在哪个主机上可以登陆;

host填入的内容

+ `localhost` ：该用户只能在本地登录，不能在另外一台机器上远程登录；

+ `IP地址` ：该用户仅能在此指定IP下正常登录；

+ `%`（缺省值） ：该用户在任何一台电脑上都可以登录；


### 创建用户

```bash
# 设置用户名，用户登录位置，用户密码
mysql> CREATE USER 'username'@'host' IDENTIFIED BY 'password';
Query OK, 0 rows affected (0.01 sec)
```

### 查看所有用户

```bash
# 切换到mysql数据库
mysql> USE mysql;
Database changed
# 显示登录位置和用户名
mysql> SELECT host,user FROM user;
+-----------+------------------+
| host      | user             |
+-----------+------------------+
| ···       | ···              |
| localhost | mysql.infoschema |
| localhost | mysql.session    |
| localhost | mysql.sys        |
| localhost | root             |
+-----------+------------------+
···
```

### 删除用户

```bash
# 删除指定用户
mysql> DROP USER 'username'@'host';
Query OK, 0 rows affected (0.00 sec)
```

### 授予用户权限

+ `privileges` ：用户的操作权限，如SELECT，INSERT，UPDATE等，ALL可授予全部权限；

+ `databasename` ：授权的数据库名，使用 `*` 可授权所有数据库；

+ `tablename` ：授权的表名，使用 `*` 可授权数据库下所有表；

> 使用 `*.*`可授权所有数据库及其表

```bash
# 指定用户对特定数据库或特定表名的权限
mysql> GRANT privileges ON databasename.tablename TO 'username'@'host';
Query OK, 0 rows affected (0.00 sec)
```

### 查看用户权限

```bash
mysql> SHOW GRANTS FOR 'username'@'host';
+----------------------------------------------------+
| Grants for `···`@`···`                             |
+----------------------------------------------------+
| GRANT USAGE ON *.* TO `···`@`···`                  |
| ···                                                |
+----------------------------------------------------+
```

### 收回用户权限

> 参数使用同 `GRANT`

```bash
# 收回用户对特定数据库或特定表名的权限
mysql> REVOKE privileges ON databasename.tablename FROM 'username'@'host';
Query OK, 0 rows affected (0.00 sec)
```
